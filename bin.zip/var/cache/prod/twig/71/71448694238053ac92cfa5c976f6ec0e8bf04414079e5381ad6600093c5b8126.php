<?php

/* Partials/maninmenu.html.twig */
class __TwigTemplate_0ecae0c74cccc5c6674c7be1f8ee3a682486514a496d88ba983f67ee2f89786f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c517511d2467f7dae844d023ddeb5f5d0191dc51902350ad518a944d45a22c87 = $this->env->getExtension("native_profiler");
        $__internal_c517511d2467f7dae844d023ddeb5f5d0191dc51902350ad518a944d45a22c87->enter($__internal_c517511d2467f7dae844d023ddeb5f5d0191dc51902350ad518a944d45a22c87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Partials/maninmenu.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-default navbar-fixed-top\">
    <div class=\"container-fluid navbar-inverse\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"inicio\">";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["marca"]) ? $context["marca"] : $this->getContext($context, "marca")), "html", null, true);
        echo "</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
            <ul class=\"nav navbar-nav\">
                <li class=\"dropdown\">
                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                        La Empresa <span class=\"caret\"></span>
                    </a>
                    <ul class=\"dropdown-menu\">
                        <li class=\"disabled\"><a href=\"#\">Breve Reseña</a></li>
                        <li><a href=\"empresa-mision\">Misión - Visión - Valores</a></li>
                        <li class=\"divider\"></li>
                        <li class=\"disabled\"><a href=\"inicio\">Staff</a></li>
                    </ul>
                </li>
                <li class=\"disabled\"><a href=\"\">Nuestros Servicios</a></li>
                <li><a href=\"contacto\">Contacto</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>";
        
        $__internal_c517511d2467f7dae844d023ddeb5f5d0191dc51902350ad518a944d45a22c87->leave($__internal_c517511d2467f7dae844d023ddeb5f5d0191dc51902350ad518a944d45a22c87_prof);

    }

    public function getTemplateName()
    {
        return "Partials/maninmenu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 11,  22 => 1,);
    }
}
/* <nav class="navbar navbar-default navbar-fixed-top">*/
/*     <div class="container-fluid navbar-inverse">*/
/*         <!-- Brand and toggle get grouped for better mobile display -->*/
/*         <div class="navbar-header">*/
/*             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">*/
/*                 <span class="sr-only">Toggle navigation</span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*             </button>*/
/*             <a class="navbar-brand" href="inicio">{{ marca }}</a>*/
/*         </div>*/
/* */
/*         <!-- Collect the nav links, forms, and other content for toggling -->*/
/*         <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">*/
/*             <ul class="nav navbar-nav">*/
/*                 <li class="dropdown">*/
/*                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">*/
/*                         La Empresa <span class="caret"></span>*/
/*                     </a>*/
/*                     <ul class="dropdown-menu">*/
/*                         <li class="disabled"><a href="#">Breve Reseña</a></li>*/
/*                         <li><a href="empresa-mision">Misión - Visión - Valores</a></li>*/
/*                         <li class="divider"></li>*/
/*                         <li class="disabled"><a href="inicio">Staff</a></li>*/
/*                     </ul>*/
/*                 </li>*/
/*                 <li class="disabled"><a href="">Nuestros Servicios</a></li>*/
/*                 <li><a href="contacto">Contacto</a></li>*/
/*             </ul>*/
/*         </div><!-- /.navbar-collapse -->*/
/*     </div><!-- /.container-fluid -->*/
/* </nav>*/
