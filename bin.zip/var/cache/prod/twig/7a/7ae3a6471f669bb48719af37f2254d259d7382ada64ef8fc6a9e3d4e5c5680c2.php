<?php

/* Partials/maninmenu.html.twig */
class __TwigTemplate_b8c8adb83a833c96062e2bcf10fa8954a26fab877a2ccf4379b9e92d4e64eb8b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-default\">
    <div class=\"container-fluid navbar-inverse\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"#\">";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["marca"]) ? $context["marca"] : null), "html", null, true);
        echo "</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
            <ul class=\"nav navbar-nav\">
                <li class=\"dropdown\">
                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                        La Empresa <span class=\"caret\"></span>
                    </a>
                    <ul class=\"dropdown-menu\">
                        <li><a href=\"inicio\">Misión</a></li>
                        <li><a href=\"inicio\">Visión</a></li>
                        <li><a href=\"inicio\">Valores</a></li>
                        <li class=\"divider\"></li>
                        <li class=\"disabled\"><a href=\"inicio\">Staff</a></li>
                    </ul>
                </li>
                <li><a href=\"\">Contacto</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>";
    }

    public function getTemplateName()
    {
        return "Partials/maninmenu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 11,  19 => 1,);
    }
}
/* <nav class="navbar navbar-default">*/
/*     <div class="container-fluid navbar-inverse">*/
/*         <!-- Brand and toggle get grouped for better mobile display -->*/
/*         <div class="navbar-header">*/
/*             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">*/
/*                 <span class="sr-only">Toggle navigation</span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*             </button>*/
/*             <a class="navbar-brand" href="#">{{ marca }}</a>*/
/*         </div>*/
/* */
/*         <!-- Collect the nav links, forms, and other content for toggling -->*/
/*         <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">*/
/*             <ul class="nav navbar-nav">*/
/*                 <li class="dropdown">*/
/*                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">*/
/*                         La Empresa <span class="caret"></span>*/
/*                     </a>*/
/*                     <ul class="dropdown-menu">*/
/*                         <li><a href="inicio">Misión</a></li>*/
/*                         <li><a href="inicio">Visión</a></li>*/
/*                         <li><a href="inicio">Valores</a></li>*/
/*                         <li class="divider"></li>*/
/*                         <li class="disabled"><a href="inicio">Staff</a></li>*/
/*                     </ul>*/
/*                 </li>*/
/*                 <li><a href="">Contacto</a></li>*/
/*             </ul>*/
/*         </div><!-- /.navbar-collapse -->*/
/*     </div><!-- /.container-fluid -->*/
/* </nav>*/
