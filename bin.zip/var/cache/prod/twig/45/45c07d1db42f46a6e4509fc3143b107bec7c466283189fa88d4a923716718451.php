<?php

/* default/contacto.html.twig */
class __TwigTemplate_ca09054c6f5acebf0d1ca99fa4d6b18112617a4f99699d21ceb7179cbf0d25ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout-responsive.html.twig", "default/contacto.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-responsive.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d9bdd2168e331464dcc99c55d49bc6342fdcd286fe30c5e09956fd1a456f9a9 = $this->env->getExtension("native_profiler");
        $__internal_6d9bdd2168e331464dcc99c55d49bc6342fdcd286fe30c5e09956fd1a456f9a9->enter($__internal_6d9bdd2168e331464dcc99c55d49bc6342fdcd286fe30c5e09956fd1a456f9a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/contacto.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6d9bdd2168e331464dcc99c55d49bc6342fdcd286fe30c5e09956fd1a456f9a9->leave($__internal_6d9bdd2168e331464dcc99c55d49bc6342fdcd286fe30c5e09956fd1a456f9a9_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_3ab31a1fd81f5d2ce30da496417fa4b25e75783cb62e4ca896863eb3f14adb15 = $this->env->getExtension("native_profiler");
        $__internal_3ab31a1fd81f5d2ce30da496417fa4b25e75783cb62e4ca896863eb3f14adb15->enter($__internal_3ab31a1fd81f5d2ce30da496417fa4b25e75783cb62e4ca896863eb3f14adb15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Contacto";
        
        $__internal_3ab31a1fd81f5d2ce30da496417fa4b25e75783cb62e4ca896863eb3f14adb15->leave($__internal_3ab31a1fd81f5d2ce30da496417fa4b25e75783cb62e4ca896863eb3f14adb15_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_53adc9edbbb429b2217cacdb9d7022ce24286f2d75be102259a43b12774b26e7 = $this->env->getExtension("native_profiler");
        $__internal_53adc9edbbb429b2217cacdb9d7022ce24286f2d75be102259a43b12774b26e7->enter($__internal_53adc9edbbb429b2217cacdb9d7022ce24286f2d75be102259a43b12774b26e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "\t";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
\t<link href=\"css/estilos.css\" rel=\"stylesheet\">
";
        
        $__internal_53adc9edbbb429b2217cacdb9d7022ce24286f2d75be102259a43b12774b26e7->leave($__internal_53adc9edbbb429b2217cacdb9d7022ce24286f2d75be102259a43b12774b26e7_prof);

    }

    // line 14
    public function block_content($context, array $blocks = array())
    {
        $__internal_396c8bebba8610458bb9efbdf882b56067798fcfaff9aef9e96fbf2f83373e09 = $this->env->getExtension("native_profiler");
        $__internal_396c8bebba8610458bb9efbdf882b56067798fcfaff9aef9e96fbf2f83373e09->enter($__internal_396c8bebba8610458bb9efbdf882b56067798fcfaff9aef9e96fbf2f83373e09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 15
        echo "\t";
        $this->displayParentBlock("content", $context, $blocks);
        echo "
\t<br>
\t<div class=\"row\">
\t\t<div class=\"col-md-7\">
\t\t\t<img src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/contacto-mapa.jpg"), "html", null, true);
        echo "\" alt=\"mapa\" class=\"img-responsive img-thumbnail\">
\t\t</div>
\t\t<div class=\"col-md-4\">

\t\t\t<div class=\"panel panel-info\">
\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t<h3 class=\"panel-title\">Información</h3>
\t\t\t\t\t</div>
\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t<strong>Dirección:</strong> República de Colombia esquina Caballero <br><br>
\t\t\t\t\t<strong>Referencia: </strong>Frente al Edificio Alicante <br><br>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<br>
";
        
        $__internal_396c8bebba8610458bb9efbdf882b56067798fcfaff9aef9e96fbf2f83373e09->leave($__internal_396c8bebba8610458bb9efbdf882b56067798fcfaff9aef9e96fbf2f83373e09_prof);

    }

    public function getTemplateName()
    {
        return "default/contacto.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 19,  71 => 15,  65 => 14,  54 => 8,  48 => 7,  36 => 4,  11 => 1,);
    }
}
/* {% extends 'layout-responsive.html.twig' %}*/
/* */
/* */
/* {% block title %}Contacto{% endblock %}*/
/* */
/* */
/* {% block stylesheets%}*/
/* 	{{ parent() }}*/
/* 	<link href="css/estilos.css" rel="stylesheet">*/
/* {% endblock %}*/
/* */
/* */
/* */
/* {% block content %}*/
/* 	{{ parent() }}*/
/* 	<br>*/
/* 	<div class="row">*/
/* 		<div class="col-md-7">*/
/* 			<img src="{{ asset('img/contacto-mapa.jpg') }}" alt="mapa" class="img-responsive img-thumbnail">*/
/* 		</div>*/
/* 		<div class="col-md-4">*/
/* */
/* 			<div class="panel panel-info">*/
/* 					<div class="panel-heading">*/
/* 						<h3 class="panel-title">Información</h3>*/
/* 					</div>*/
/* 				<div class="panel-body">*/
/* 					<strong>Dirección:</strong> República de Colombia esquina Caballero <br><br>*/
/* 					<strong>Referencia: </strong>Frente al Edificio Alicante <br><br>*/
/* 				</div>*/
/* 			</div>*/
/* 		</div>*/
/* 	</div>*/
/* 	<br>*/
/* {% endblock %}*/
