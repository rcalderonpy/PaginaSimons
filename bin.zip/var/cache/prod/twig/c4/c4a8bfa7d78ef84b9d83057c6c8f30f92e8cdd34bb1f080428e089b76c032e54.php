<?php

/* default/index.html.twig */
class __TwigTemplate_21afaad5c5c6671838e0d668c362b393875b2d925bb0ec776c1522d10bc848e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout-responsive.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-responsive.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Simons Estudio Contable";
    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 8
        echo "\t";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
\t<link href=\"../../web/css/estilos.css\" rel=\"stylesheet\">
\t
";
    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        // line 14
        echo "\t";
        $this->displayParentBlock("content", $context, $blocks);
        echo "
\t<div class=\"row\">
\t\t<div class=\"col-xs-12 col-sm-9 col-md-7\">
\t\t\t";
        // line 17
        $this->loadTemplate("Partials/carousel.html.twig", "default/index.html.twig", 17)->display($context);
        // line 18
        echo "\t\t</div>
\t\t<div class=\"col-xs-0 col-sm-3 col-md-5\"></div>
\t\t
\t</div>
\t<br/>
\t
";
    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 18,  58 => 17,  51 => 14,  48 => 13,  39 => 8,  36 => 7,  30 => 4,  11 => 1,);
    }
}
/* {% extends 'layout-responsive.html.twig' %}*/
/* */
/* */
/* {% block title %}Simons Estudio Contable{% endblock %}*/
/* */
/* */
/* {% block stylesheets%}*/
/* 	{{ parent() }}*/
/* 	<link href="../../web/css/estilos.css" rel="stylesheet">*/
/* 	*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/* 	{{ parent() }}*/
/* 	<div class="row">*/
/* 		<div class="col-xs-12 col-sm-9 col-md-7">*/
/* 			{% include 'Partials/carousel.html.twig' %}*/
/* 		</div>*/
/* 		<div class="col-xs-0 col-sm-3 col-md-5"></div>*/
/* 		*/
/* 	</div>*/
/* 	<br/>*/
/* 	*/
/* {% endblock %}*/
/* */
/* */
