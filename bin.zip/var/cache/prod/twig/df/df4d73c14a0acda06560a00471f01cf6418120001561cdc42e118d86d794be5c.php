<?php

/* base.html.twig */
class __TwigTemplate_4e81a689d52d112f2858cd519fc26fe795ec309bce2c7014e3658ffe363de775 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
            'foot' => array($this, 'block_foot'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d4fcb2435b42f0dcc9a9bb035643bd77859b2519f400a5cc92f3231588168024 = $this->env->getExtension("native_profiler");
        $__internal_d4fcb2435b42f0dcc9a9bb035643bd77859b2519f400a5cc92f3231588168024->enter($__internal_d4fcb2435b42f0dcc9a9bb035643bd77859b2519f400a5cc92f3231588168024_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
<head>
    <meta charset=\"UTF-8\" />
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">

    ";
        // line 7
        $this->displayBlock('metas', $context, $blocks);
        // line 8
        echo "
    <title>";
        // line 9
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\" ";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("simonsico.ico"), "html", null, true);
        echo "\" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->

</head>
<body>
";
        // line 23
        $this->displayBlock('body', $context, $blocks);
        // line 24
        $this->displayBlock('javascripts', $context, $blocks);
        // line 25
        echo "</body>
<footer>
    ";
        // line 27
        $this->displayBlock('foot', $context, $blocks);
        // line 28
        echo "</footer>
</html>
";
        
        $__internal_d4fcb2435b42f0dcc9a9bb035643bd77859b2519f400a5cc92f3231588168024->leave($__internal_d4fcb2435b42f0dcc9a9bb035643bd77859b2519f400a5cc92f3231588168024_prof);

    }

    // line 7
    public function block_metas($context, array $blocks = array())
    {
        $__internal_2fa5862695a7ac5931784e4d35762dcf5a2a72c5b59635411c21f13f173e3a08 = $this->env->getExtension("native_profiler");
        $__internal_2fa5862695a7ac5931784e4d35762dcf5a2a72c5b59635411c21f13f173e3a08->enter($__internal_2fa5862695a7ac5931784e4d35762dcf5a2a72c5b59635411c21f13f173e3a08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        
        $__internal_2fa5862695a7ac5931784e4d35762dcf5a2a72c5b59635411c21f13f173e3a08->leave($__internal_2fa5862695a7ac5931784e4d35762dcf5a2a72c5b59635411c21f13f173e3a08_prof);

    }

    // line 9
    public function block_title($context, array $blocks = array())
    {
        $__internal_bf00c26255767d33edaa2272f9c1333ba59b6e9e20823fc773e17e52bb7e4f9b = $this->env->getExtension("native_profiler");
        $__internal_bf00c26255767d33edaa2272f9c1333ba59b6e9e20823fc773e17e52bb7e4f9b->enter($__internal_bf00c26255767d33edaa2272f9c1333ba59b6e9e20823fc773e17e52bb7e4f9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "SIN TÍTULO";
        
        $__internal_bf00c26255767d33edaa2272f9c1333ba59b6e9e20823fc773e17e52bb7e4f9b->leave($__internal_bf00c26255767d33edaa2272f9c1333ba59b6e9e20823fc773e17e52bb7e4f9b_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_892e2bba7625ff96a757579831dc9703711e28ae89ff2d30f27bb682ce5a1369 = $this->env->getExtension("native_profiler");
        $__internal_892e2bba7625ff96a757579831dc9703711e28ae89ff2d30f27bb682ce5a1369->enter($__internal_892e2bba7625ff96a757579831dc9703711e28ae89ff2d30f27bb682ce5a1369_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_892e2bba7625ff96a757579831dc9703711e28ae89ff2d30f27bb682ce5a1369->leave($__internal_892e2bba7625ff96a757579831dc9703711e28ae89ff2d30f27bb682ce5a1369_prof);

    }

    // line 23
    public function block_body($context, array $blocks = array())
    {
        $__internal_4bb2662875e498c46a15f57dd002f6dd3cb8ebb5d2647ee15f7637d1237b091b = $this->env->getExtension("native_profiler");
        $__internal_4bb2662875e498c46a15f57dd002f6dd3cb8ebb5d2647ee15f7637d1237b091b->enter($__internal_4bb2662875e498c46a15f57dd002f6dd3cb8ebb5d2647ee15f7637d1237b091b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_4bb2662875e498c46a15f57dd002f6dd3cb8ebb5d2647ee15f7637d1237b091b->leave($__internal_4bb2662875e498c46a15f57dd002f6dd3cb8ebb5d2647ee15f7637d1237b091b_prof);

    }

    // line 24
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_bd02483a5f3e46d8b746eee1617344512f252eb35a92f2c2cdddb81f3a589b56 = $this->env->getExtension("native_profiler");
        $__internal_bd02483a5f3e46d8b746eee1617344512f252eb35a92f2c2cdddb81f3a589b56->enter($__internal_bd02483a5f3e46d8b746eee1617344512f252eb35a92f2c2cdddb81f3a589b56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_bd02483a5f3e46d8b746eee1617344512f252eb35a92f2c2cdddb81f3a589b56->leave($__internal_bd02483a5f3e46d8b746eee1617344512f252eb35a92f2c2cdddb81f3a589b56_prof);

    }

    // line 27
    public function block_foot($context, array $blocks = array())
    {
        $__internal_10f8379d7882f42f871f0b2ac8e120e508e0fbd3bec6824a8eafbd78cc05b52a = $this->env->getExtension("native_profiler");
        $__internal_10f8379d7882f42f871f0b2ac8e120e508e0fbd3bec6824a8eafbd78cc05b52a->enter($__internal_10f8379d7882f42f871f0b2ac8e120e508e0fbd3bec6824a8eafbd78cc05b52a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "foot"));

        
        $__internal_10f8379d7882f42f871f0b2ac8e120e508e0fbd3bec6824a8eafbd78cc05b52a->leave($__internal_10f8379d7882f42f871f0b2ac8e120e508e0fbd3bec6824a8eafbd78cc05b52a_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 27,  127 => 24,  116 => 23,  105 => 11,  93 => 9,  82 => 7,  73 => 28,  71 => 27,  67 => 25,  65 => 24,  63 => 23,  48 => 12,  46 => 11,  41 => 9,  38 => 8,  36 => 7,  28 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html lang="es">*/
/* <head>*/
/*     <meta charset="UTF-8" />*/
/*     <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/* */
/*     {% block metas %}{% endblock %}*/
/* */
/*     <title>{% block title %}SIN TÍTULO{% endblock %}</title>*/
/* */
/*     {% block stylesheets %}{% endblock %}*/
/*     <link rel="icon" type="image/x-icon" href=" {{ asset('simonsico.ico') }}" />*/
/* */
/*     <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->*/
/*     <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->*/
/*     <!--[if lt IE 9]>*/
/*     <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>*/
/*     <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>*/
/*     <![endif]-->*/
/* */
/* </head>*/
/* <body>*/
/* {% block body %}{% endblock %}*/
/* {% block javascripts %}{% endblock %}*/
/* </body>*/
/* <footer>*/
/*     {% block foot %}{% endblock %}*/
/* </footer>*/
/* </html>*/
/* */
