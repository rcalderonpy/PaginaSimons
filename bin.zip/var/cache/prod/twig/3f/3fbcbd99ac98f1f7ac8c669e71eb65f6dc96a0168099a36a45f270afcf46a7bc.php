<?php

/* default/mision.html.twig */
class __TwigTemplate_983fd5cffde6def4c7038115eb3722215f30e329d365753c1a05c28fd024b866 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout-responsive.html.twig", "default/mision.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-responsive.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d92cab45536b4d63de5b52c86ba60ea0fc025db61e8a317eac825009cb2531c = $this->env->getExtension("native_profiler");
        $__internal_3d92cab45536b4d63de5b52c86ba60ea0fc025db61e8a317eac825009cb2531c->enter($__internal_3d92cab45536b4d63de5b52c86ba60ea0fc025db61e8a317eac825009cb2531c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/mision.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3d92cab45536b4d63de5b52c86ba60ea0fc025db61e8a317eac825009cb2531c->leave($__internal_3d92cab45536b4d63de5b52c86ba60ea0fc025db61e8a317eac825009cb2531c_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_012961c196c06f2e67e77838683b63c1d141986cd5fe948bca6d0a49a4b60519 = $this->env->getExtension("native_profiler");
        $__internal_012961c196c06f2e67e77838683b63c1d141986cd5fe948bca6d0a49a4b60519->enter($__internal_012961c196c06f2e67e77838683b63c1d141986cd5fe948bca6d0a49a4b60519_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Misión";
        
        $__internal_012961c196c06f2e67e77838683b63c1d141986cd5fe948bca6d0a49a4b60519->leave($__internal_012961c196c06f2e67e77838683b63c1d141986cd5fe948bca6d0a49a4b60519_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_eeb8529625ee981220d175b5a30daa6f4daaba879e366abcd88ec7229e265f64 = $this->env->getExtension("native_profiler");
        $__internal_eeb8529625ee981220d175b5a30daa6f4daaba879e366abcd88ec7229e265f64->enter($__internal_eeb8529625ee981220d175b5a30daa6f4daaba879e366abcd88ec7229e265f64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "\t";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
\t<link href=\"css/estilos.css\" rel=\"stylesheet\">
";
        
        $__internal_eeb8529625ee981220d175b5a30daa6f4daaba879e366abcd88ec7229e265f64->leave($__internal_eeb8529625ee981220d175b5a30daa6f4daaba879e366abcd88ec7229e265f64_prof);

    }

    // line 14
    public function block_content($context, array $blocks = array())
    {
        $__internal_a37d74e49119456e6a6b087b5c69a37a985b332ecf22163d122b2f4553d082e6 = $this->env->getExtension("native_profiler");
        $__internal_a37d74e49119456e6a6b087b5c69a37a985b332ecf22163d122b2f4553d082e6->enter($__internal_a37d74e49119456e6a6b087b5c69a37a985b332ecf22163d122b2f4553d082e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 15
        echo "\t";
        $this->displayParentBlock("content", $context, $blocks);
        echo "
\t";
        // line 17
        echo "\t<div class=\"container-fluid fondoimg\">
\t
\t<div class=\"row\">
\t\t<div class=\"col-md-8\">
\t\t\t<h1 class=\"\">Misión:</h1>
\t\t\t<br>
\t\t\t<p class=\"text-left lead\"><i class=\"fa fa-quote-left text-left\" aria-hidden=\"true\"></i>
\t\t\t&nbsp;&nbsp;Brindar a nuestros clientes el mejor servicio profesional en las áreas de nuestra especialidad,
\t\t\tpara que encuentren en nosotros, una total satisfacción a los problemas que se les presentan en su actividad diaria &nbsp;&nbsp;
\t\t\t<i class=\"fa fa-quote-right\" aria-hidden=\"true\"></i>
\t\t\t</p>
\t\t</div>
\t\t<div class=\"col-md-3 col-md-offset-1 media\">
\t\t\t<img src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/mision-brujula.jpg"), "html", null, true);
        echo "\" alt=\"Brujula\" class=\"img-responsive img-rounded\">
\t\t</div>
\t\t
\t</div>
\t<br>
\t\t
\t";
        // line 37
        echo "\t<div class=\"row\">
\t\t<div class=\"col-md-3\">
\t\t\t<img src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("img/mision-brujula.jpg"), "html", null, true);
        echo "\" alt=\"Brujula\" class=\"img-responsive img-rounded\">
\t\t</div>
\t\t<div class=\"col-md-8 col-md-offset-1\">
\t\t\t
\t\t\t<h1 class=\"text-right\">Visión:</h1>
\t\t\t<br>
\t\t\t<p class=\"text-right lead\"><i class=\"fa fa-quote-left\" aria-hidden=\"true\"></i>
\t\t\t\t&nbsp;&nbsp;Brindar a nuestros clientes el mejor servicio profesional en las áreas de nuestra especialidad,
\t\t\t\tpara que encuentren en nosotros, una total satisfacción a los problemas que se les presentan en su actividad diaria &nbsp;&nbsp;
\t\t\t\t<i class=\"fa fa-quote-right\" aria-hidden=\"true\"></i>
\t\t\t</p>
\t\t</div>
\t</div>
\t
\t";
        // line 54
        echo "\t<div class=\"row\">
\t\t<div class=\"col-md-8\">
\t\t\t
\t\t\t<h1 class=\"\">Valores:</h1>
\t\t\t<br>
\t\t\t<p class=\"lead\"> <i class=\"fa fa-balance-scale\" aria-hidden=\"true\"></i> Integridad</p>
\t\t\t<p class=\"lead\"> <i class=\"fa fa-balance-scale\" aria-hidden=\"true\"></i> Responsabilidad</p>
\t\t\t<p class=\"lead\"> <i class=\"fa fa-balance-scale\" aria-hidden=\"true\"></i> Eficiencia</p>
\t\t\t<p class=\"lead\"> <i class=\"fa fa-balance-scale\" aria-hidden=\"true\"></i> Confidencialidad</p>
\t\t\t<p class=\"lead\"> <i class=\"fa fa-balance-scale\" aria-hidden=\"true\"></i> Respeto hacia los clientes y empleados</p>
\t
\t\t
\t\t</div>
\t\t
\t</div>
\t<br>
\t</div>
";
        
        $__internal_a37d74e49119456e6a6b087b5c69a37a985b332ecf22163d122b2f4553d082e6->leave($__internal_a37d74e49119456e6a6b087b5c69a37a985b332ecf22163d122b2f4553d082e6_prof);

    }

    public function getTemplateName()
    {
        return "default/mision.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 54,  104 => 39,  100 => 37,  91 => 30,  76 => 17,  71 => 15,  65 => 14,  54 => 8,  48 => 7,  36 => 4,  11 => 1,);
    }
}
/* {% extends 'layout-responsive.html.twig' %}*/
/* */
/* */
/* {% block title %}Misión{% endblock %}*/
/* */
/* */
/* {% block stylesheets%}*/
/* 	{{ parent() }}*/
/* 	<link href="css/estilos.css" rel="stylesheet">*/
/* {% endblock %}*/
/* */
/* */
/* */
/* {% block content %}*/
/* 	{{ parent() }}*/
/* 	{#Misión#}*/
/* 	<div class="container-fluid fondoimg">*/
/* 	*/
/* 	<div class="row">*/
/* 		<div class="col-md-8">*/
/* 			<h1 class="">Misión:</h1>*/
/* 			<br>*/
/* 			<p class="text-left lead"><i class="fa fa-quote-left text-left" aria-hidden="true"></i>*/
/* 			&nbsp;&nbsp;Brindar a nuestros clientes el mejor servicio profesional en las áreas de nuestra especialidad,*/
/* 			para que encuentren en nosotros, una total satisfacción a los problemas que se les presentan en su actividad diaria &nbsp;&nbsp;*/
/* 			<i class="fa fa-quote-right" aria-hidden="true"></i>*/
/* 			</p>*/
/* 		</div>*/
/* 		<div class="col-md-3 col-md-offset-1 media">*/
/* 			<img src="{{ asset('img/mision-brujula.jpg') }}" alt="Brujula" class="img-responsive img-rounded">*/
/* 		</div>*/
/* 		*/
/* 	</div>*/
/* 	<br>*/
/* 		*/
/* 	{#Visión#}*/
/* 	<div class="row">*/
/* 		<div class="col-md-3">*/
/* 			<img src="{{ asset('img/mision-brujula.jpg') }}" alt="Brujula" class="img-responsive img-rounded">*/
/* 		</div>*/
/* 		<div class="col-md-8 col-md-offset-1">*/
/* 			*/
/* 			<h1 class="text-right">Visión:</h1>*/
/* 			<br>*/
/* 			<p class="text-right lead"><i class="fa fa-quote-left" aria-hidden="true"></i>*/
/* 				&nbsp;&nbsp;Brindar a nuestros clientes el mejor servicio profesional en las áreas de nuestra especialidad,*/
/* 				para que encuentren en nosotros, una total satisfacción a los problemas que se les presentan en su actividad diaria &nbsp;&nbsp;*/
/* 				<i class="fa fa-quote-right" aria-hidden="true"></i>*/
/* 			</p>*/
/* 		</div>*/
/* 	</div>*/
/* 	*/
/* 	{#Valores#}*/
/* 	<div class="row">*/
/* 		<div class="col-md-8">*/
/* 			*/
/* 			<h1 class="">Valores:</h1>*/
/* 			<br>*/
/* 			<p class="lead"> <i class="fa fa-balance-scale" aria-hidden="true"></i> Integridad</p>*/
/* 			<p class="lead"> <i class="fa fa-balance-scale" aria-hidden="true"></i> Responsabilidad</p>*/
/* 			<p class="lead"> <i class="fa fa-balance-scale" aria-hidden="true"></i> Eficiencia</p>*/
/* 			<p class="lead"> <i class="fa fa-balance-scale" aria-hidden="true"></i> Confidencialidad</p>*/
/* 			<p class="lead"> <i class="fa fa-balance-scale" aria-hidden="true"></i> Respeto hacia los clientes y empleados</p>*/
/* 	*/
/* 		*/
/* 		</div>*/
/* 		*/
/* 	</div>*/
/* 	<br>*/
/* 	</div>*/
/* {% endblock %}*/
/* */
/* */
