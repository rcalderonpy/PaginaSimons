<?php

/* Partials/carousel.html.twig */
class __TwigTemplate_1b539b0fe882a4ff061cc87f40836388980f81e705eedbc5d59325398089436c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
\t<!-- Indicators -->
\t<ol class=\"carousel-indicators\">
\t\t<li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
\t\t<li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
\t\t<li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
\t</ol>
\t
\t<!-- Wrapper for slides -->
\t<div class=\"carousel-inner\" role=\"listbox\">
\t\t<div class=\"item active\">
\t\t\t<img src=\"../../web/img/img1.jpg\" sizes=\"50px\">
\t\t\t<div class=\"carousel-caption\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"item\">
\t\t\t<img src=\"../../web/img/img2.jpg\" sizes=\"50px\">
\t\t\t<div class=\"carousel-caption\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"item\">
\t\t\t<img src=\"../../web/img/img3.jpg\" sizes=\"50px\">
\t\t\t<div class=\"carousel-caption\">
\t\t\t</div>
\t\t</div>
\t</div>
\t
\t<!-- Controls -->
\t<a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\">
\t\t<span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
\t\t<span class=\"sr-only\">Previous</span>
\t</a>
\t<a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\">
\t\t<span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
\t\t<span class=\"sr-only\">Next</span>
\t</a>
</div>";
    }

    public function getTemplateName()
    {
        return "Partials/carousel.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">*/
/* 	<!-- Indicators -->*/
/* 	<ol class="carousel-indicators">*/
/* 		<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>*/
/* 		<li data-target="#carousel-example-generic" data-slide-to="1"></li>*/
/* 		<li data-target="#carousel-example-generic" data-slide-to="2"></li>*/
/* 	</ol>*/
/* 	*/
/* 	<!-- Wrapper for slides -->*/
/* 	<div class="carousel-inner" role="listbox">*/
/* 		<div class="item active">*/
/* 			<img src="../../web/img/img1.jpg" sizes="50px">*/
/* 			<div class="carousel-caption">*/
/* 			</div>*/
/* 		</div>*/
/* 		<div class="item">*/
/* 			<img src="../../web/img/img2.jpg" sizes="50px">*/
/* 			<div class="carousel-caption">*/
/* 			</div>*/
/* 		</div>*/
/* 		<div class="item">*/
/* 			<img src="../../web/img/img3.jpg" sizes="50px">*/
/* 			<div class="carousel-caption">*/
/* 			</div>*/
/* 		</div>*/
/* 	</div>*/
/* 	*/
/* 	<!-- Controls -->*/
/* 	<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">*/
/* 		<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>*/
/* 		<span class="sr-only">Previous</span>*/
/* 	</a>*/
/* 	<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">*/
/* 		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>*/
/* 		<span class="sr-only">Next</span>*/
/* 	</a>*/
/* </div>*/
