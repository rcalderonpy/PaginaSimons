<?php

/* default/index.html.twig */
class __TwigTemplate_140820143d1e91d774b8e867fbf00fe3c3bd4eb14b796a779ab36e0723da818e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout-responsive.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-responsive.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_918beb2cbe5f5e53d0a36c7bb8415ad9f63ec43aa05d5e2071d9af03fed1b2f3 = $this->env->getExtension("native_profiler");
        $__internal_918beb2cbe5f5e53d0a36c7bb8415ad9f63ec43aa05d5e2071d9af03fed1b2f3->enter($__internal_918beb2cbe5f5e53d0a36c7bb8415ad9f63ec43aa05d5e2071d9af03fed1b2f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_918beb2cbe5f5e53d0a36c7bb8415ad9f63ec43aa05d5e2071d9af03fed1b2f3->leave($__internal_918beb2cbe5f5e53d0a36c7bb8415ad9f63ec43aa05d5e2071d9af03fed1b2f3_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_0c788e94bc157c8dac5758b1985fdb52609095921f30c6e424a3ac4b90f68edc = $this->env->getExtension("native_profiler");
        $__internal_0c788e94bc157c8dac5758b1985fdb52609095921f30c6e424a3ac4b90f68edc->enter($__internal_0c788e94bc157c8dac5758b1985fdb52609095921f30c6e424a3ac4b90f68edc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Simons Estudio Contable";
        
        $__internal_0c788e94bc157c8dac5758b1985fdb52609095921f30c6e424a3ac4b90f68edc->leave($__internal_0c788e94bc157c8dac5758b1985fdb52609095921f30c6e424a3ac4b90f68edc_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_13d86daa21a98e21fe84730b1eb5c2f3347bfd3a8dbf8819170aeffc8f4519ae = $this->env->getExtension("native_profiler");
        $__internal_13d86daa21a98e21fe84730b1eb5c2f3347bfd3a8dbf8819170aeffc8f4519ae->enter($__internal_13d86daa21a98e21fe84730b1eb5c2f3347bfd3a8dbf8819170aeffc8f4519ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "\t";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
\t<link href=\"css/estilos.css\" rel=\"stylesheet\">
";
        
        $__internal_13d86daa21a98e21fe84730b1eb5c2f3347bfd3a8dbf8819170aeffc8f4519ae->leave($__internal_13d86daa21a98e21fe84730b1eb5c2f3347bfd3a8dbf8819170aeffc8f4519ae_prof);

    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        $__internal_9e8e90935e863f472f756296e755825af79f197e77d2ea6caf40c087ec37bd0a = $this->env->getExtension("native_profiler");
        $__internal_9e8e90935e863f472f756296e755825af79f197e77d2ea6caf40c087ec37bd0a->enter($__internal_9e8e90935e863f472f756296e755825af79f197e77d2ea6caf40c087ec37bd0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 14
        echo "\t";
        $this->displayParentBlock("content", $context, $blocks);
        echo "
\t<br>
\t<div class=\"row\">
\t\t<div class=\"col-xs-12 col-sm-9 col-md-7\">
\t\t\t";
        // line 18
        $this->loadTemplate("Partials/carousel.html.twig", "default/index.html.twig", 18)->display($context);
        // line 19
        echo "\t\t</div>
\t\t<div class=\"col-xs-0 col-sm-3 col-md-5\"></div>
\t</div>
\t<br/>
";
        
        $__internal_9e8e90935e863f472f756296e755825af79f197e77d2ea6caf40c087ec37bd0a->leave($__internal_9e8e90935e863f472f756296e755825af79f197e77d2ea6caf40c087ec37bd0a_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 19,  79 => 18,  71 => 14,  65 => 13,  54 => 8,  48 => 7,  36 => 4,  11 => 1,);
    }
}
/* {% extends 'layout-responsive.html.twig' %}*/
/* */
/* */
/* {% block title %}Simons Estudio Contable{% endblock %}*/
/* */
/* */
/* {% block stylesheets%}*/
/* 	{{ parent() }}*/
/* 	<link href="css/estilos.css" rel="stylesheet">*/
/* {% endblock %}*/
/* */
/* */
/* {% block content %}*/
/* 	{{ parent() }}*/
/* 	<br>*/
/* 	<div class="row">*/
/* 		<div class="col-xs-12 col-sm-9 col-md-7">*/
/* 			{% include 'Partials/carousel.html.twig' %}*/
/* 		</div>*/
/* 		<div class="col-xs-0 col-sm-3 col-md-5"></div>*/
/* 	</div>*/
/* 	<br/>*/
/* {% endblock %}*/
/* */
/* */
