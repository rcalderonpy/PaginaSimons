<?php

/* layout-responsive.html.twig */
class __TwigTemplate_f32a9891c44bda7ee569a63a706f1acd787e030182fe4f46525b0e20b8c1310c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "layout-responsive.html.twig", 1);
        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
            'foot' => array($this, 'block_foot'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3350e4f70221587ac143ca8dc2adb26f7553b1f249e87492027d8eebbcee447a = $this->env->getExtension("native_profiler");
        $__internal_3350e4f70221587ac143ca8dc2adb26f7553b1f249e87492027d8eebbcee447a->enter($__internal_3350e4f70221587ac143ca8dc2adb26f7553b1f249e87492027d8eebbcee447a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout-responsive.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3350e4f70221587ac143ca8dc2adb26f7553b1f249e87492027d8eebbcee447a->leave($__internal_3350e4f70221587ac143ca8dc2adb26f7553b1f249e87492027d8eebbcee447a_prof);

    }

    // line 2
    public function block_metas($context, array $blocks = array())
    {
        $__internal_98d9548b8eff768302f1785f8b065d57405be0716a05dc4193ff1f9dc8fad89c = $this->env->getExtension("native_profiler");
        $__internal_98d9548b8eff768302f1785f8b065d57405be0716a05dc4193ff1f9dc8fad89c->enter($__internal_98d9548b8eff768302f1785f8b065d57405be0716a05dc4193ff1f9dc8fad89c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        // line 3
        echo "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
";
        
        $__internal_98d9548b8eff768302f1785f8b065d57405be0716a05dc4193ff1f9dc8fad89c->leave($__internal_98d9548b8eff768302f1785f8b065d57405be0716a05dc4193ff1f9dc8fad89c_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_dbc00a4be2b945b89957cb3d758d2d27ffad008cec12c29c4f334d7f05f6c75a = $this->env->getExtension("native_profiler");
        $__internal_dbc00a4be2b945b89957cb3d758d2d27ffad008cec12c29c4f334d7f05f6c75a->enter($__internal_dbc00a4be2b945b89957cb3d758d2d27ffad008cec12c29c4f334d7f05f6c75a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "    <link href=\"Bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"font-awesome/css/font-awesome.min.css\">
";
        
        $__internal_dbc00a4be2b945b89957cb3d758d2d27ffad008cec12c29c4f334d7f05f6c75a->leave($__internal_dbc00a4be2b945b89957cb3d758d2d27ffad008cec12c29c4f334d7f05f6c75a_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_806279ce5c1626d696b5898f16b4c6953d73d10f9a3662d578b020c96351390b = $this->env->getExtension("native_profiler");
        $__internal_806279ce5c1626d696b5898f16b4c6953d73d10f9a3662d578b020c96351390b->enter($__internal_806279ce5c1626d696b5898f16b4c6953d73d10f9a3662d578b020c96351390b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "     ";
        $this->loadTemplate("Partials/maninmenu.html.twig", "layout-responsive.html.twig", 12)->display(array_merge($context, array("marca" => "Simons Estudio Contable")));
        // line 13
        echo "     <section class=\"container\">
         ";
        // line 14
        $this->displayBlock('content', $context, $blocks);
        // line 15
        echo "     </section>
     ";
        // line 16
        $this->displayBlock('javascripts', $context, $blocks);
        // line 20
        echo " ";
        
        $__internal_806279ce5c1626d696b5898f16b4c6953d73d10f9a3662d578b020c96351390b->leave($__internal_806279ce5c1626d696b5898f16b4c6953d73d10f9a3662d578b020c96351390b_prof);

    }

    // line 14
    public function block_content($context, array $blocks = array())
    {
        $__internal_2cbf38ee0594d2a3bd100d8dc24483667ce4b57aa10385b70370a05d4d71ca43 = $this->env->getExtension("native_profiler");
        $__internal_2cbf38ee0594d2a3bd100d8dc24483667ce4b57aa10385b70370a05d4d71ca43->enter($__internal_2cbf38ee0594d2a3bd100d8dc24483667ce4b57aa10385b70370a05d4d71ca43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        echo " ";
        
        $__internal_2cbf38ee0594d2a3bd100d8dc24483667ce4b57aa10385b70370a05d4d71ca43->leave($__internal_2cbf38ee0594d2a3bd100d8dc24483667ce4b57aa10385b70370a05d4d71ca43_prof);

    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_77b00f2b9b900163717d5a0cf5a872be0f7a612cfb5be25538375ea51c9de470 = $this->env->getExtension("native_profiler");
        $__internal_77b00f2b9b900163717d5a0cf5a872be0f7a612cfb5be25538375ea51c9de470->enter($__internal_77b00f2b9b900163717d5a0cf5a872be0f7a612cfb5be25538375ea51c9de470_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 17
        echo "         <script src=\"Bootstrap/js/bootstrap.min.js\"></script>
         <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
     ";
        
        $__internal_77b00f2b9b900163717d5a0cf5a872be0f7a612cfb5be25538375ea51c9de470->leave($__internal_77b00f2b9b900163717d5a0cf5a872be0f7a612cfb5be25538375ea51c9de470_prof);

    }

    // line 23
    public function block_foot($context, array $blocks = array())
    {
        $__internal_6cd668727f4ccb0039206fa33fbb24e67342033d203010b948c16256124b77ed = $this->env->getExtension("native_profiler");
        $__internal_6cd668727f4ccb0039206fa33fbb24e67342033d203010b948c16256124b77ed->enter($__internal_6cd668727f4ccb0039206fa33fbb24e67342033d203010b948c16256124b77ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "foot"));

        // line 24
        echo "    <div class=\"container-fluid footerlocal navbar-fixed-bottom\">
        <div class=\"row\">
            <div class=\"col-md-7 col-md-offset-1\">
                <address>
                    <br>
                    <span class=\"text-muted\">República de Colombia esq. Caballero</span><br>
                    <span class=\"text-muted\">Asunción - Paraguay</span><br>
                    <abbr title=\"Phone\"><span class=\"text-muted\">Tel:</span></abbr>
                    <span class=\"text-muted\">(595 21) 496-509 </span><br>
                    <abbr title=\"Email\"><span class=\"text-muted\">Email:</span></abbr> <a href=\"mailto:atencion@simons.com.py\" >atencion@simons.com.py</a>
                </address>
            </div>
            <div class=\"col-md-3 text-right\">
                <br>
                <br>
                <br>
                <br>
                <address><strong class=\"text-muted\">Diseñado por <cite>Rodrigo Calderón</cite></address>
            </div>
        </div>
    </div>
";
        
        $__internal_6cd668727f4ccb0039206fa33fbb24e67342033d203010b948c16256124b77ed->leave($__internal_6cd668727f4ccb0039206fa33fbb24e67342033d203010b948c16256124b77ed_prof);

    }

    public function getTemplateName()
    {
        return "layout-responsive.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 24,  121 => 23,  112 => 17,  106 => 16,  94 => 14,  87 => 20,  85 => 16,  82 => 15,  80 => 14,  77 => 13,  74 => 12,  68 => 11,  59 => 7,  53 => 6,  45 => 3,  39 => 2,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* {% block metas %}*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1">*/
/* {% endblock %}*/
/* */
/* {% block stylesheets %}*/
/*     <link href="Bootstrap/css/bootstrap.min.css" rel="stylesheet">*/
/*     <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">*/
/* {% endblock %}*/
/* */
/*  {% block body %}*/
/*      {% include 'Partials/maninmenu.html.twig' with {'marca':'Simons Estudio Contable'} %}*/
/*      <section class="container">*/
/*          {% block content %} {% endblock %}*/
/*      </section>*/
/*      {% block javascripts %}*/
/*          <script src="Bootstrap/js/bootstrap.min.js"></script>*/
/*          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>*/
/*      {% endblock %}*/
/*  {% endblock %}*/
/* */
/* {#PIE DE PAGINA#}*/
/* {% block foot %}*/
/*     <div class="container-fluid footerlocal navbar-fixed-bottom">*/
/*         <div class="row">*/
/*             <div class="col-md-7 col-md-offset-1">*/
/*                 <address>*/
/*                     <br>*/
/*                     <span class="text-muted">República de Colombia esq. Caballero</span><br>*/
/*                     <span class="text-muted">Asunción - Paraguay</span><br>*/
/*                     <abbr title="Phone"><span class="text-muted">Tel:</span></abbr>*/
/*                     <span class="text-muted">(595 21) 496-509 </span><br>*/
/*                     <abbr title="Email"><span class="text-muted">Email:</span></abbr> <a href="mailto:atencion@simons.com.py" >atencion@simons.com.py</a>*/
/*                 </address>*/
/*             </div>*/
/*             <div class="col-md-3 text-right">*/
/*                 <br>*/
/*                 <br>*/
/*                 <br>*/
/*                 <br>*/
/*                 <address><strong class="text-muted">Diseñado por <cite>Rodrigo Calderón</cite></address>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
