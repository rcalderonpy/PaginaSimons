<?php

/* layout-responsive.html.twig */
class __TwigTemplate_cad9f014201a7b4c386a1cd8909c55d2f7286d3fd4f3bb478fb99fc6a966a0e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "layout-responsive.html.twig", 1);
        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_metas($context, array $blocks = array())
    {
        // line 3
        echo "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
";
    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 7
        echo "    <link href=\"../../web/Bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
";
    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        // line 11
        echo "     ";
        $this->loadTemplate("Partials/maninmenu.html.twig", "layout-responsive.html.twig", 11)->display(array_merge($context, array("marca" => "Simons Estudio Contable")));
        // line 12
        echo "     


     <div class=\"container\">
                  
         ";
        // line 17
        $this->displayBlock('content', $context, $blocks);
        // line 18
        echo "     </div>

     ";
        // line 21
        echo "     <div class=\"navbar navbar-fixed-bottom\">
         <div class=\"container-fluid navbar-inverse\">
             <div class=\"container\">
                 <address>
                     <br>
                     <span class=\"text-muted\">República de Colombia esq. Caballero</span><br>
                     <span class=\"text-muted\">Asunción - Paraguay</span><br>
                     <abbr title=\"Phone\"><span class=\"text-muted\">Tel:</span></abbr>
                     <span class=\"text-muted\">(595 21) 496-509 </span><br>
                     <abbr title=\"Email\"><span class=\"text-muted\">Email:</span></abbr> <a href=\"mailto:atencion@simons.com.py\" >atencion@simons.com.py</a>
                 </address>
                 
                     <footer class=\"text-muted text-right\"><strong>Diseñado por </strong><cite title=\"Rodrigo Calderón\">Rodrigo Calderón</cite></footer>
             </div>
         </div>
     </div>
     

     ";
        // line 39
        $this->displayBlock('javascripts', $context, $blocks);
        // line 43
        echo "
 ";
    }

    // line 17
    public function block_content($context, array $blocks = array())
    {
        echo " ";
    }

    // line 39
    public function block_javascripts($context, array $blocks = array())
    {
        // line 40
        echo "         <script src=\"../../web/Bootstrap/js/bootstrap.min.js\"></script>
         <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
     ";
    }

    public function getTemplateName()
    {
        return "layout-responsive.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 40,  100 => 39,  94 => 17,  89 => 43,  87 => 39,  67 => 21,  63 => 18,  61 => 17,  54 => 12,  51 => 11,  48 => 10,  43 => 7,  40 => 6,  35 => 3,  32 => 2,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* {% block metas %}*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1">*/
/* {% endblock %}*/
/* */
/* {% block stylesheets %}*/
/*     <link href="../../web/Bootstrap/css/bootstrap.min.css" rel="stylesheet">*/
/* {% endblock %}*/
/* */
/*  {% block body %}*/
/*      {% include 'Partials/maninmenu.html.twig' with {'marca':'Simons Estudio Contable'} %}*/
/*      */
/* */
/* */
/*      <div class="container">*/
/*                   */
/*          {% block content %} {% endblock %}*/
/*      </div>*/
/* */
/*      {#PIE DE PAGINA#}*/
/*      <div class="navbar navbar-fixed-bottom">*/
/*          <div class="container-fluid navbar-inverse">*/
/*              <div class="container">*/
/*                  <address>*/
/*                      <br>*/
/*                      <span class="text-muted">República de Colombia esq. Caballero</span><br>*/
/*                      <span class="text-muted">Asunción - Paraguay</span><br>*/
/*                      <abbr title="Phone"><span class="text-muted">Tel:</span></abbr>*/
/*                      <span class="text-muted">(595 21) 496-509 </span><br>*/
/*                      <abbr title="Email"><span class="text-muted">Email:</span></abbr> <a href="mailto:atencion@simons.com.py" >atencion@simons.com.py</a>*/
/*                  </address>*/
/*                  */
/*                      <footer class="text-muted text-right"><strong>Diseñado por </strong><cite title="Rodrigo Calderón">Rodrigo Calderón</cite></footer>*/
/*              </div>*/
/*          </div>*/
/*      </div>*/
/*      */
/* */
/*      {% block javascripts %}*/
/*          <script src="../../web/Bootstrap/js/bootstrap.min.js"></script>*/
/*          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>*/
/*      {% endblock %}*/
/* */
/*  {% endblock %}*/
