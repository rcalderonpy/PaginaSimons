<?php

/* layout-responsive.html.twig */
class __TwigTemplate_6a22d38ab644c1fb5a4e1ec95648ed8a0f7e5d4fa7cf83e01e57e68d8a3802dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "layout-responsive.html.twig", 1);
        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8f05a3b18b57707a026d68c247e7498ca0e59f38d446a5ff8f44b0245171442 = $this->env->getExtension("native_profiler");
        $__internal_d8f05a3b18b57707a026d68c247e7498ca0e59f38d446a5ff8f44b0245171442->enter($__internal_d8f05a3b18b57707a026d68c247e7498ca0e59f38d446a5ff8f44b0245171442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout-responsive.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d8f05a3b18b57707a026d68c247e7498ca0e59f38d446a5ff8f44b0245171442->leave($__internal_d8f05a3b18b57707a026d68c247e7498ca0e59f38d446a5ff8f44b0245171442_prof);

    }

    // line 2
    public function block_metas($context, array $blocks = array())
    {
        $__internal_07a2d30b0206bf4482c878b18fde7e8f1b51807d1a1f4b1d81b94943a461c808 = $this->env->getExtension("native_profiler");
        $__internal_07a2d30b0206bf4482c878b18fde7e8f1b51807d1a1f4b1d81b94943a461c808->enter($__internal_07a2d30b0206bf4482c878b18fde7e8f1b51807d1a1f4b1d81b94943a461c808_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        // line 3
        echo "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
";
        
        $__internal_07a2d30b0206bf4482c878b18fde7e8f1b51807d1a1f4b1d81b94943a461c808->leave($__internal_07a2d30b0206bf4482c878b18fde7e8f1b51807d1a1f4b1d81b94943a461c808_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_320546e4a8441ee5204f281b1e8ae4672e73e3d5a2e3c6c3cd5e104b3ed875a4 = $this->env->getExtension("native_profiler");
        $__internal_320546e4a8441ee5204f281b1e8ae4672e73e3d5a2e3c6c3cd5e104b3ed875a4->enter($__internal_320546e4a8441ee5204f281b1e8ae4672e73e3d5a2e3c6c3cd5e104b3ed875a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "    <link href=\"../../web/Bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
";
        
        $__internal_320546e4a8441ee5204f281b1e8ae4672e73e3d5a2e3c6c3cd5e104b3ed875a4->leave($__internal_320546e4a8441ee5204f281b1e8ae4672e73e3d5a2e3c6c3cd5e104b3ed875a4_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_48fe07a9a67ef708623d13922041f49838b33f84e335eb04dd9d37a34c148834 = $this->env->getExtension("native_profiler");
        $__internal_48fe07a9a67ef708623d13922041f49838b33f84e335eb04dd9d37a34c148834->enter($__internal_48fe07a9a67ef708623d13922041f49838b33f84e335eb04dd9d37a34c148834_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "     ";
        $this->loadTemplate("Partials/maninmenu.html.twig", "layout-responsive.html.twig", 11)->display(array_merge($context, array("marca" => "Simons Estudio Contable")));
        // line 12
        echo "     


     <div class=\"container\">
                  
         ";
        // line 17
        $this->displayBlock('content', $context, $blocks);
        // line 18
        echo "     </div>

     ";
        // line 21
        echo "     <div class=\"navbar navbar-fixed-bottom\">
         <div class=\"container-fluid navbar-inverse\">
             <div class=\"container\">
                 <address>
                     <br>
                     <span class=\"text-muted\">República de Colombia esq. Caballero</span><br>
                     <span class=\"text-muted\">Asunción - Paraguay</span><br>
                     <abbr title=\"Phone\"><span class=\"text-muted\">Tel:</span></abbr>
                     <span class=\"text-muted\">(595 21) 496-509 </span><br>
                     <abbr title=\"Email\"><span class=\"text-muted\">Email:</span></abbr> <a href=\"mailto:atencion@simons.com.py\" >atencion@simons.com.py</a>
                 </address>
                 
                     <footer class=\"text-muted text-right\"><strong>Diseñado por </strong><cite title=\"Rodrigo Calderón\">Rodrigo Calderón</cite></footer>
             </div>
         </div>
     </div>
     

     ";
        // line 39
        $this->displayBlock('javascripts', $context, $blocks);
        // line 43
        echo "
 ";
        
        $__internal_48fe07a9a67ef708623d13922041f49838b33f84e335eb04dd9d37a34c148834->leave($__internal_48fe07a9a67ef708623d13922041f49838b33f84e335eb04dd9d37a34c148834_prof);

    }

    // line 17
    public function block_content($context, array $blocks = array())
    {
        $__internal_7b85e99879aa6c111479712c0cd1e3f760be901e42bff9d0ed7661e0eb661298 = $this->env->getExtension("native_profiler");
        $__internal_7b85e99879aa6c111479712c0cd1e3f760be901e42bff9d0ed7661e0eb661298->enter($__internal_7b85e99879aa6c111479712c0cd1e3f760be901e42bff9d0ed7661e0eb661298_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        echo " ";
        
        $__internal_7b85e99879aa6c111479712c0cd1e3f760be901e42bff9d0ed7661e0eb661298->leave($__internal_7b85e99879aa6c111479712c0cd1e3f760be901e42bff9d0ed7661e0eb661298_prof);

    }

    // line 39
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_74408d3969ae2554a7571a2ff36fa04d27aad4c11bff92fd4e17ea8db2594aa1 = $this->env->getExtension("native_profiler");
        $__internal_74408d3969ae2554a7571a2ff36fa04d27aad4c11bff92fd4e17ea8db2594aa1->enter($__internal_74408d3969ae2554a7571a2ff36fa04d27aad4c11bff92fd4e17ea8db2594aa1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 40
        echo "         <script src=\"../../web/Bootstrap/js/bootstrap.min.js\"></script>
         <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
     ";
        
        $__internal_74408d3969ae2554a7571a2ff36fa04d27aad4c11bff92fd4e17ea8db2594aa1->leave($__internal_74408d3969ae2554a7571a2ff36fa04d27aad4c11bff92fd4e17ea8db2594aa1_prof);

    }

    public function getTemplateName()
    {
        return "layout-responsive.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 40,  130 => 39,  118 => 17,  110 => 43,  108 => 39,  88 => 21,  84 => 18,  82 => 17,  75 => 12,  72 => 11,  66 => 10,  58 => 7,  52 => 6,  44 => 3,  38 => 2,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* {% block metas %}*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1">*/
/* {% endblock %}*/
/* */
/* {% block stylesheets %}*/
/*     <link href="../../web/Bootstrap/css/bootstrap.min.css" rel="stylesheet">*/
/* {% endblock %}*/
/* */
/*  {% block body %}*/
/*      {% include 'Partials/maninmenu.html.twig' with {'marca':'Simons Estudio Contable'} %}*/
/*      */
/* */
/* */
/*      <div class="container">*/
/*                   */
/*          {% block content %} {% endblock %}*/
/*      </div>*/
/* */
/*      {#PIE DE PAGINA#}*/
/*      <div class="navbar navbar-fixed-bottom">*/
/*          <div class="container-fluid navbar-inverse">*/
/*              <div class="container">*/
/*                  <address>*/
/*                      <br>*/
/*                      <span class="text-muted">República de Colombia esq. Caballero</span><br>*/
/*                      <span class="text-muted">Asunción - Paraguay</span><br>*/
/*                      <abbr title="Phone"><span class="text-muted">Tel:</span></abbr>*/
/*                      <span class="text-muted">(595 21) 496-509 </span><br>*/
/*                      <abbr title="Email"><span class="text-muted">Email:</span></abbr> <a href="mailto:atencion@simons.com.py" >atencion@simons.com.py</a>*/
/*                  </address>*/
/*                  */
/*                      <footer class="text-muted text-right"><strong>Diseñado por </strong><cite title="Rodrigo Calderón">Rodrigo Calderón</cite></footer>*/
/*              </div>*/
/*          </div>*/
/*      </div>*/
/*      */
/* */
/*      {% block javascripts %}*/
/*          <script src="../../web/Bootstrap/js/bootstrap.min.js"></script>*/
/*          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>*/
/*      {% endblock %}*/
/* */
/*  {% endblock %}*/
