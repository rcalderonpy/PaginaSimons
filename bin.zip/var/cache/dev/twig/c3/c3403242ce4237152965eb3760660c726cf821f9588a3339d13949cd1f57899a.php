<?php

/* default/index.html.twig */
class __TwigTemplate_b796fdf40926d53036594416388cc1b5c2fd811b6445e02a27dd18e6f0c59f6f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout-responsive.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-responsive.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd9518b8c8c47e5a17a0da54a76b42f3e6eedd4e4443cc3b3e8b846e4689274e = $this->env->getExtension("native_profiler");
        $__internal_fd9518b8c8c47e5a17a0da54a76b42f3e6eedd4e4443cc3b3e8b846e4689274e->enter($__internal_fd9518b8c8c47e5a17a0da54a76b42f3e6eedd4e4443cc3b3e8b846e4689274e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fd9518b8c8c47e5a17a0da54a76b42f3e6eedd4e4443cc3b3e8b846e4689274e->leave($__internal_fd9518b8c8c47e5a17a0da54a76b42f3e6eedd4e4443cc3b3e8b846e4689274e_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_d911c0a543f9b0cc09e784627c08ed3b7a859ff67ed310a1224a5dfb6f41a3ac = $this->env->getExtension("native_profiler");
        $__internal_d911c0a543f9b0cc09e784627c08ed3b7a859ff67ed310a1224a5dfb6f41a3ac->enter($__internal_d911c0a543f9b0cc09e784627c08ed3b7a859ff67ed310a1224a5dfb6f41a3ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Simons Estudio Contable";
        
        $__internal_d911c0a543f9b0cc09e784627c08ed3b7a859ff67ed310a1224a5dfb6f41a3ac->leave($__internal_d911c0a543f9b0cc09e784627c08ed3b7a859ff67ed310a1224a5dfb6f41a3ac_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b1c850b9830619778ea1c29e278dff6ec4445558bab4fcd46410745fc9a09595 = $this->env->getExtension("native_profiler");
        $__internal_b1c850b9830619778ea1c29e278dff6ec4445558bab4fcd46410745fc9a09595->enter($__internal_b1c850b9830619778ea1c29e278dff6ec4445558bab4fcd46410745fc9a09595_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "\t";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
\t<link href=\"../../web/css/estilos.css\" rel=\"stylesheet\">
\t
";
        
        $__internal_b1c850b9830619778ea1c29e278dff6ec4445558bab4fcd46410745fc9a09595->leave($__internal_b1c850b9830619778ea1c29e278dff6ec4445558bab4fcd46410745fc9a09595_prof);

    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        $__internal_ced678f5d5dab48ab7636ae8390f0b9f20f8fb44ba80b9fd2eeda8be6f3cf5fb = $this->env->getExtension("native_profiler");
        $__internal_ced678f5d5dab48ab7636ae8390f0b9f20f8fb44ba80b9fd2eeda8be6f3cf5fb->enter($__internal_ced678f5d5dab48ab7636ae8390f0b9f20f8fb44ba80b9fd2eeda8be6f3cf5fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 14
        echo "\t";
        $this->displayParentBlock("content", $context, $blocks);
        echo "
\t<div class=\"row\">
\t\t<div class=\"col-xs-12 col-sm-9 col-md-7\">
\t\t\t";
        // line 17
        $this->loadTemplate("Partials/carousel.html.twig", "default/index.html.twig", 17)->display($context);
        // line 18
        echo "\t\t</div>
\t\t<div class=\"col-xs-0 col-sm-3 col-md-5\"></div>
\t\t
\t</div>
\t<br/>
\t
";
        
        $__internal_ced678f5d5dab48ab7636ae8390f0b9f20f8fb44ba80b9fd2eeda8be6f3cf5fb->leave($__internal_ced678f5d5dab48ab7636ae8390f0b9f20f8fb44ba80b9fd2eeda8be6f3cf5fb_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 18,  79 => 17,  72 => 14,  66 => 13,  54 => 8,  48 => 7,  36 => 4,  11 => 1,);
    }
}
/* {% extends 'layout-responsive.html.twig' %}*/
/* */
/* */
/* {% block title %}Simons Estudio Contable{% endblock %}*/
/* */
/* */
/* {% block stylesheets%}*/
/* 	{{ parent() }}*/
/* 	<link href="../../web/css/estilos.css" rel="stylesheet">*/
/* 	*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/* 	{{ parent() }}*/
/* 	<div class="row">*/
/* 		<div class="col-xs-12 col-sm-9 col-md-7">*/
/* 			{% include 'Partials/carousel.html.twig' %}*/
/* 		</div>*/
/* 		<div class="col-xs-0 col-sm-3 col-md-5"></div>*/
/* 		*/
/* 	</div>*/
/* 	<br/>*/
/* 	*/
/* {% endblock %}*/
/* */
/* */
