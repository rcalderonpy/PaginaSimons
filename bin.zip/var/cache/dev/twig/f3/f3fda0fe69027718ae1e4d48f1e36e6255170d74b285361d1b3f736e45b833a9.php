<?php

/* base.html.twig */
class __TwigTemplate_d9df6c50c8ef9a29d3b6fd36b57a4a8fc00065eed8ea55a1e8067d6d17144023 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20321ad3dd3e51e5991df91546901b5ba981b2fe40b16701af641277ff4d260e = $this->env->getExtension("native_profiler");
        $__internal_20321ad3dd3e51e5991df91546901b5ba981b2fe40b16701af641277ff4d260e->enter($__internal_20321ad3dd3e51e5991df91546901b5ba981b2fe40b16701af641277ff4d260e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
<head>
    <meta charset=\"UTF-8\" />
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">

    ";
        // line 7
        $this->displayBlock('metas', $context, $blocks);
        // line 8
        echo "
    <title>";
        // line 9
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\" ";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("simonsico.ico"), "html", null, true);
        echo "\" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->

</head>
<body>
";
        // line 23
        $this->displayBlock('body', $context, $blocks);
        // line 24
        echo "
";
        // line 25
        $this->displayBlock('javascripts', $context, $blocks);
        // line 26
        echo "

</body>
</html>
";
        
        $__internal_20321ad3dd3e51e5991df91546901b5ba981b2fe40b16701af641277ff4d260e->leave($__internal_20321ad3dd3e51e5991df91546901b5ba981b2fe40b16701af641277ff4d260e_prof);

    }

    // line 7
    public function block_metas($context, array $blocks = array())
    {
        $__internal_02e22d457f631f5a46aac02b85ad094da30fddd4c07aafd8d9d5c812905d26df = $this->env->getExtension("native_profiler");
        $__internal_02e22d457f631f5a46aac02b85ad094da30fddd4c07aafd8d9d5c812905d26df->enter($__internal_02e22d457f631f5a46aac02b85ad094da30fddd4c07aafd8d9d5c812905d26df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        
        $__internal_02e22d457f631f5a46aac02b85ad094da30fddd4c07aafd8d9d5c812905d26df->leave($__internal_02e22d457f631f5a46aac02b85ad094da30fddd4c07aafd8d9d5c812905d26df_prof);

    }

    // line 9
    public function block_title($context, array $blocks = array())
    {
        $__internal_140f8f6327dd2bbaedf2681a4f42f4656bf3add4ebbebe1a90e56302687d51ce = $this->env->getExtension("native_profiler");
        $__internal_140f8f6327dd2bbaedf2681a4f42f4656bf3add4ebbebe1a90e56302687d51ce->enter($__internal_140f8f6327dd2bbaedf2681a4f42f4656bf3add4ebbebe1a90e56302687d51ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "SIN TÍTULO";
        
        $__internal_140f8f6327dd2bbaedf2681a4f42f4656bf3add4ebbebe1a90e56302687d51ce->leave($__internal_140f8f6327dd2bbaedf2681a4f42f4656bf3add4ebbebe1a90e56302687d51ce_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_de1c370fc1df25c6e29f822e54419a587a7f26afd83f42c38547726a3b063f2e = $this->env->getExtension("native_profiler");
        $__internal_de1c370fc1df25c6e29f822e54419a587a7f26afd83f42c38547726a3b063f2e->enter($__internal_de1c370fc1df25c6e29f822e54419a587a7f26afd83f42c38547726a3b063f2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_de1c370fc1df25c6e29f822e54419a587a7f26afd83f42c38547726a3b063f2e->leave($__internal_de1c370fc1df25c6e29f822e54419a587a7f26afd83f42c38547726a3b063f2e_prof);

    }

    // line 23
    public function block_body($context, array $blocks = array())
    {
        $__internal_181b4b4217c53afc9589a4e97b4ac6d44666af283a3d169b67859f93a9673587 = $this->env->getExtension("native_profiler");
        $__internal_181b4b4217c53afc9589a4e97b4ac6d44666af283a3d169b67859f93a9673587->enter($__internal_181b4b4217c53afc9589a4e97b4ac6d44666af283a3d169b67859f93a9673587_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_181b4b4217c53afc9589a4e97b4ac6d44666af283a3d169b67859f93a9673587->leave($__internal_181b4b4217c53afc9589a4e97b4ac6d44666af283a3d169b67859f93a9673587_prof);

    }

    // line 25
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_972526821260582397bf8d50f0640193f82d3930c37f04fff20a2044a3258b37 = $this->env->getExtension("native_profiler");
        $__internal_972526821260582397bf8d50f0640193f82d3930c37f04fff20a2044a3258b37->enter($__internal_972526821260582397bf8d50f0640193f82d3930c37f04fff20a2044a3258b37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_972526821260582397bf8d50f0640193f82d3930c37f04fff20a2044a3258b37->leave($__internal_972526821260582397bf8d50f0640193f82d3930c37f04fff20a2044a3258b37_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 25,  114 => 23,  103 => 11,  91 => 9,  80 => 7,  69 => 26,  67 => 25,  64 => 24,  62 => 23,  47 => 12,  45 => 11,  40 => 9,  37 => 8,  35 => 7,  27 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html lang="es">*/
/* <head>*/
/*     <meta charset="UTF-8" />*/
/*     <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/* */
/*     {% block metas %}{% endblock %}*/
/* */
/*     <title>{% block title %}SIN TÍTULO{% endblock %}</title>*/
/* */
/*     {% block stylesheets %}{% endblock %}*/
/*     <link rel="icon" type="image/x-icon" href=" {{ asset('simonsico.ico') }}" />*/
/* */
/*     <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->*/
/*     <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->*/
/*     <!--[if lt IE 9]>*/
/*     <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>*/
/*     <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>*/
/*     <![endif]-->*/
/* */
/* </head>*/
/* <body>*/
/* {% block body %}{% endblock %}*/
/* */
/* {% block javascripts %}{% endblock %}*/
/* */
/* */
/* </body>*/
/* </html>*/
/* */
