<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_a6ab422987622e1864bc6853d8a31ef8d92dbb0409ee366bf6408dcdbe6fa0fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f962a1d2243002135c1df57871ac383a21af7e9a0a6d962ae0d023e78bcb0f77 = $this->env->getExtension("native_profiler");
        $__internal_f962a1d2243002135c1df57871ac383a21af7e9a0a6d962ae0d023e78bcb0f77->enter($__internal_f962a1d2243002135c1df57871ac383a21af7e9a0a6d962ae0d023e78bcb0f77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f962a1d2243002135c1df57871ac383a21af7e9a0a6d962ae0d023e78bcb0f77->leave($__internal_f962a1d2243002135c1df57871ac383a21af7e9a0a6d962ae0d023e78bcb0f77_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_d0777767959de5a7bb8369cdcd92855e5506cc41d02c229ebcdcafdfd4f0eebf = $this->env->getExtension("native_profiler");
        $__internal_d0777767959de5a7bb8369cdcd92855e5506cc41d02c229ebcdcafdfd4f0eebf->enter($__internal_d0777767959de5a7bb8369cdcd92855e5506cc41d02c229ebcdcafdfd4f0eebf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_d0777767959de5a7bb8369cdcd92855e5506cc41d02c229ebcdcafdfd4f0eebf->leave($__internal_d0777767959de5a7bb8369cdcd92855e5506cc41d02c229ebcdcafdfd4f0eebf_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_14aac72f8e06cd8a61c67b23c738f07477f7589688579247cc415209ec1944fe = $this->env->getExtension("native_profiler");
        $__internal_14aac72f8e06cd8a61c67b23c738f07477f7589688579247cc415209ec1944fe->enter($__internal_14aac72f8e06cd8a61c67b23c738f07477f7589688579247cc415209ec1944fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_14aac72f8e06cd8a61c67b23c738f07477f7589688579247cc415209ec1944fe->leave($__internal_14aac72f8e06cd8a61c67b23c738f07477f7589688579247cc415209ec1944fe_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_bee4c60cc835bbf16c3fd76fbed8568e58b6ebafa8820ffce3a297fa03f2cf96 = $this->env->getExtension("native_profiler");
        $__internal_bee4c60cc835bbf16c3fd76fbed8568e58b6ebafa8820ffce3a297fa03f2cf96->enter($__internal_bee4c60cc835bbf16c3fd76fbed8568e58b6ebafa8820ffce3a297fa03f2cf96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_bee4c60cc835bbf16c3fd76fbed8568e58b6ebafa8820ffce3a297fa03f2cf96->leave($__internal_bee4c60cc835bbf16c3fd76fbed8568e58b6ebafa8820ffce3a297fa03f2cf96_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
