<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{
    public function indexAction(Request $request)
    {
        // abre la página inicial
        return $this->render('default/index.html.twig', [
            'base_dir' => '']);

    }

    public function misionAction(Request $request)
    {
        // abre la página mision
        return $this->render('default/mision.html.twig', [
            'base_dir' => '']);

    }
    public function contactoAction(Request $request)
    {
        // abre la página contacto
        return $this->render('default/contacto.html.twig', [
            'base_dir' => '']);

    }
}

